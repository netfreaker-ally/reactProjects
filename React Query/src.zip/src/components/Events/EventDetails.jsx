import { Link, Outlet, useNavigate, useParams } from "react-router-dom";

import Header from "../Header.jsx";
import { useMutation, useQuery } from "@tanstack/react-query";
import { deleteEvent, fetchEvent, queryClient } from "../../util/http.js";
import ErrorBlock from "../UI/ErrorBlock.jsx";
import LoadingIndicator from "../UI/LoadingIndicator.jsx";

export default function EventDetails() {
  const event = useParams();
  const id = event.id;
  const navigate = useNavigate();
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["events", { eventId: id }],
    queryFn: ({ signal }) => fetchEvent({ id, signal }),
  });
  const {
    mutate,
    isError: isErrorDeleting,
    error: isErrorDeletingMessage,
    isPending,
  } = useMutation({
    mutationFn: deleteEvent,
    onSuccess: () => {
      navigate("/events"),
        queryClient.invalidateQueries({ queryKey: ["event"] });
    },
  });
  function handleDelete() {
    mutate({ id });
    console.log("in handleSubmit");
  }
  return (
    <>
      <Outlet />
      <Header>
        <Link to="/events" className="nav-item">
          View all Events
        </Link>
      </Header>
      {isLoading && <p>Loading........</p>}
      {isPending && (
        <>
          <p>Deleting.......</p>
          <LoadingIndicator />
        </>
      )}
      {}
      {isError && (
        <ErrorBlock
          title="Error while Fetching details of id"
          message={
            error.info?.message || "Got error while fetching data of this event"
          }
        />
      )}
      {isErrorDeleting && (
        <ErrorBlock
          title="Error while Deleting"
          message={
            isErrorDeletingMessage.info?.message || "Error while Deleting"
          }
        />
      )}
      {data && (
        <article id="event-details">
          <header>
            <h1>{data.title}</h1>
            <nav>
              <button onClick={handleDelete}>Delete</button>
              <Link to="edit">Edit</Link>
            </nav>
          </header>
          <div id="event-details-content">
            <img src={`http://localhost:3000/${data.image}`} alt="" />
            <div id="event-details-info">
              <div>
                <p id="event-details-location">{data.location}</p>
                <time dateTime={`Todo-DateT$Todo-Time`}>{data.date}</time>
              </div>
              <p id="event-details-description">{data.description}</p>
            </div>
          </div>
        </article>
      )}
    </>
  );
}
